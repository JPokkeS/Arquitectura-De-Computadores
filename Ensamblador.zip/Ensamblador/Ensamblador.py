import os
import sys

#Definicion de los registros
reg_dict = {"x0": 0, "x1": 1, "x2": 2, "x3": 3,
            "x4": 4, "x5": 5, "x6": 6, "x7": 7,
            "x8": 8, "x9": 9, "x10": 10, "x11": 11,
            "x12": 12, "x13": 13, "x14": 14, "x15": 15,
            "x16": 16, "x17": 17, "x18": 18, "x19": 19,
            "x20": 20, "x21": 21, "x22": 22, "x23": 23,
            "x24": 24, "x25": 25, "x26": 26, "x27": 27,
            "x28": 28, "x29": 29, "x30": 30, "x31": 31}

#Creamos el diccionario de labels
labels_dict = dict()
a = ["00000000"] * 1024

#Buscamos el archivo
#archivo = input("Ingresar el nombre del archivo: ")
archivo = "programa.txt"

#Leemos el archivo
contador_inst = -1
with open(os.path.join(sys.path[0], archivo), "rt") as f:
    for linea in f:
        linea = linea.strip() #Quitar espacios en blanco
        if not(linea == ''): #Ignoramos las lineas vacias
            contador_inst = contador_inst + 1
            linea_c = linea.split('//') #Separamos el comentario
            linea_c = linea_c[0].split(':')
            if len(linea_c) == 2:
                if not linea_c[0].isnumeric():
                    new_label = {linea_c[0] : contador_inst}
                    labels_dict.update(new_label)
                    contador_inst = contador_inst - 1

print("Labels del programa:")
print(labels_dict)
print("\n")

#Traduccion
contador_inst = -1
with open(os.path.join(sys.path[0], archivo), "rt") as f:
    for linea in f:
        linea = linea.strip() #Quitar espacios en blanco
        if not(linea == ''): #Ignoramos las lineas vacias
            contador_inst = contador_inst + 1
            cont_inst_hexa = hex(contador_inst*4)[2:]
            linea_c = linea.split('//') #Separamos el comentario
            linea_c = linea_c[0].split(':')
            if len(linea_c) == 2:
                if linea_c[0].isnumeric():
                    asm = ''
                    data_hex = int(linea_c[0], 16)
                    data_values = linea_c[1].split(',') #Separamos los valores
                    for data_val in data_values:
                        data_val_t = data_val.strip()
                        a[data_hex] = data_val_t
                        data_hex = data_hex + 2
                else:
                    asm = linea_c[1].strip()
            else:
                asm = linea_c[0].strip()
            if not(asm == ''):
                asm = asm.split(' ', 1) #Separamos opcode de la instruccion
                if asm[0] == "add": 
                    opcode = format(0b0110011, 'b').zfill(7)
                    func7 = format(0b0000000, 'b').zfill(7)
                    func3 = format(0b000, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rB = regs[2].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    cmd_code = func7+rB_val+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex
                
                elif asm[0] == "sub":
                    opcode = format(0b0110011, 'b').zfill(7)
                    func7 = format(0b0100000, 'b').zfill(7)
                    func3 = format(0b000, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rB = regs[2].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    cmd_code = func7+rB_val+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "xor":
                    opcode = format(0b0110011, 'b').zfill(7)
                    func7 = format(0b0000000, 'b').zfill(7)
                    func3 = format(0b100, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rB = regs[2].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    cmd_code = func7+rB_val+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "or":
                    opcode = format(0b0110011, 'b').zfill(7)
                    func7 = format(0b0000000, 'b').zfill(7)
                    func3 = format(0b110, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rB = regs[2].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    cmd_code = func7+rB_val+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "and":
                    opcode = format(0b0110011, 'b').zfill(7)
                    func7 = format(0b0000000, 'b').zfill(7)
                    func3 = format(0b111, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rB = regs[2].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    cmd_code = func7+rB_val+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "sll":
                    opcode = format(0b0110011, 'b').zfill(7)
                    func7 = format(0b0000000, 'b').zfill(7)
                    func3 = format(0b001, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rB = regs[2].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    cmd_code = func7+rB_val+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "srl":
                    opcode = format(0b0110011, 'b').zfill(7)
                    func7 = format(0b0000000, 'b').zfill(7)
                    func3 = format(0b101, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rB = regs[2].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    cmd_code = func7+rB_val+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "sra":
                    opcode = format(0b0110011, 'b').zfill(7)
                    func7 = format(0b0100000, 'b').zfill(7)
                    func3 = format(0b101, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rB = regs[2].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    cmd_code = func7+rB_val+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "slt":
                    opcode = format(0b0110011, 'b').zfill(7)
                    func7 = format(0b0000000, 'b').zfill(7)
                    func3 = format(0b010, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rB = regs[2].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    cmd_code = func7+rB_val+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "sltu":
                    opcode = format(0b0110011, 'b').zfill(7)
                    func7 = format(0b0000000, 'b').zfill(7)
                    func3 = format(0b011, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rB = regs[2].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    cmd_code = func7+rB_val+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "addi": 
                    opcode = format(0b0010011, 'b').zfill(7)
                    func3 = format(0b000, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[2].strip() )
                    offset_val_binB = (bin(immdt_decimal& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB
                    
                    cmd_code = offset_val_bin12b+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "xori":
                    opcode = format(0b0010011, 'b').zfill(7)
                    func3 = format(0b100, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[2].strip() )
                    offset_val_binB = (bin(immdt_decimal& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB
                    cmd_code = offset_val_bin12b+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "ori":
                    opcode = format(0b0010011, 'b').zfill(7)
                    func3 = format(0b110, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[2].strip() )
                    offset_val_binB = (bin(immdt_decimal& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB
                    cmd_code = offset_val_bin12b+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex
                
                elif asm[0] == "andi":
                    opcode = format(0b0010011, 'b').zfill(7)
                    func3 = format(0b111, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[2].strip() )
                    offset_val_binB = (bin(immdt_decimal& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB
                    cmd_code = offset_val_bin12b+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "slli":
                    opcode = format(0b0010011, 'b').zfill(7)
                    func3 = format(0b001, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[2].strip() ) #shamt
                    offset_val_binB = (bin(immdt_decimal& 0b111111111111).replace('0b', '')).zfill(5)
                    offset_val_bin5b = offset_val_binB
                    cmd_code = offset_val_bin5b+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "srli":
                    opcode = format(0b0010011, 'b').zfill(7)
                    func3 = format(0b101, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[2].strip() ) #shamt
                    offset_val_binB = (bin(immdt_decimal& 0b111111111111).replace('0b', '')).zfill(5)
                    offset_val_bin5b = offset_val_binB
                    cmd_code = offset_val_bin5b+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "srai":
                    opcode = format(0b0010011, 'b').zfill(7)
                    func3 = format(0b101, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[2].strip() ) #shamt
                    imm = immdt_decimal & 0b111111111111  # Solo para asegurar que los bits 5 a 11 estén en 0
                    imm |= 0x20 << 5 #Desplazamiento de bits
                    offset_val_binB = (bin(imm).replace('0b', '')).zfill(5)
                    offset_val_bin5b = offset_val_binB
                    cmd_code = offset_val_bin5b+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "slti":
                    opcode = format(0b0010011, 'b').zfill(7)
                    func3 = format(0b010, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[2].strip() )
                    offset_val_binB = (bin(immdt_decimal& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB
                    cmd_code = offset_val_bin12b+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "sltiu":
                    opcode = format(0b0010011, 'b').zfill(7)
                    func3 = format(0b011, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[2].strip() )
                    offset_val_binB = (bin(immdt_decimal& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB
                    cmd_code = offset_val_bin12b+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex
                
                elif asm[0] == "lb":
                    opcode = format(0b0000011, 'b').zfill(7)
                    func3 = format(0b000, 'b').zfill(3)
                    regs = asm[1].split(',')
                    off_rS =  (regs[1].strip()).replace(')', '')
                    rD = regs[0].strip()
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    off_rS_spl = off_rS.split('(')
                    rS1 = off_rS_spl[1].strip()
                    rS1_val = format(reg_dict[rS1], 'b').zfill(5)
                    offset_val = int(off_rS_spl[0], 10) 
                    offset_val_binB = (bin(offset_val& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB[-12:]
                    cmd_code = offset_val_bin12b + rS1_val + func3 + rD_val + opcode  
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex
                
                elif asm[0] == "lh":
                    opcode = format(0b0000011, 'b').zfill(7)
                    func3 = format(0b001, 'b').zfill(3)
                    regs = asm[1].split(',')
                    off_rS =  (regs[1].strip()).replace(')', '')
                    rD = regs[0].strip()
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    off_rS_spl = off_rS.split('(')
                    rS1 = off_rS_spl[1].strip()
                    rS1_val = format(reg_dict[rS1], 'b').zfill(5)
                    offset_val = int(off_rS_spl[0], 10) 
                    offset_val_binB = (bin(offset_val& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB[-12:]
                    cmd_code = offset_val_bin12b + rS1_val + func3 + rD_val + opcode  
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "lw":
                    opcode = format(0b0000011, 'b').zfill(7)
                    func3 = format(0b010, 'b').zfill(3)
                    regs = asm[1].split(',')
                    off_rS =  (regs[1].strip()).replace(')', '')
                    rD = regs[0].strip()
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    off_rS_spl = off_rS.split('(')
                    rS1 = off_rS_spl[1].strip()
                    rS1_val = format(reg_dict[rS1], 'b').zfill(5)
                    offset_val = int(off_rS_spl[0], 10) #convert decimal string (denoting offset) to an integer
                    offset_val_binB = (bin(offset_val& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB[-12:]
                    cmd_code = offset_val_bin12b + rS1_val + func3 + rD_val + opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "lbu":
                    opcode = format(0b0000011, 'b').zfill(7)
                    func3 = format(0b100, 'b').zfill(3)
                    regs = asm[1].split(',')
                    off_rS =  (regs[1].strip()).replace(')', '')
                    rD = regs[0].strip()
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    off_rS_spl = off_rS.split('(')
                    rS1 = off_rS_spl[1].strip()
                    rS1_val = format(reg_dict[rS1], 'b').zfill(5)
                    offset_val = int(off_rS_spl[0], 10) 
                    offset_val_binB = (bin(offset_val& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB[-12:]
                    cmd_code = offset_val_bin12b + rS1_val + func3 + rD_val + opcode  
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "lhu":
                    opcode = format(0b0000011, 'b').zfill(7)
                    func3 = format(0b01, 'b').zfill(3)
                    regs = asm[1].split(',')
                    off_rS =  (regs[1].strip()).replace(')', '')
                    rD = regs[0].strip()
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    off_rS_spl = off_rS.split('(')
                    rS1 = off_rS_spl[1].strip()
                    rS1_val = format(reg_dict[rS1], 'b').zfill(5)
                    offset_val = int(off_rS_spl[0], 10) 
                    offset_val_binB = (bin(offset_val& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB[-12:]
                    cmd_code = offset_val_bin12b + rS1_val + func3 + rD_val + opcode  
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "sb":
                    opcode = format(0b0100011, 'b').zfill(7)
                    func3 = format(0b000, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rS2 = regs[0].strip()
                    rS2_val =  format(reg_dict[rS2], 'b').zfill(5)
                    off_rS =  (regs[1].strip()).replace(')', '')
                    off_rS_spl = off_rS.split('(')
                    rS1 = off_rS_spl[1].strip()
                    rS1_val = format(reg_dict[rS1], 'b').zfill(5)
                    offset_val = int(off_rS_spl[0], 10) 
                    offset_val_binB = (bin(offset_val& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB[-12:]
                    cmd_code = offset_val_bin12b[0:7] + rS2_val + rS1_val + func3 + offset_val_bin12b[7:12] + opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8) 
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "sh":
                    opcode = format(0b0100011, 'b').zfill(7)
                    func3 = format(0b001, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rS2 = regs[0].strip()
                    rS2_val =  format(reg_dict[rS2], 'b').zfill(5)
                    off_rS =  (regs[1].strip()).replace(')', '')
                    off_rS_spl = off_rS.split('(')
                    rS1 = off_rS_spl[1].strip()
                    rS1_val = format(reg_dict[rS1], 'b').zfill(5)
                    offset_val = int(off_rS_spl[0], 10)
                    offset_val_binB = (bin(offset_val& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB[-12:]
                    cmd_code = offset_val_bin12b[0:7] + rS2_val + rS1_val + func3 + offset_val_bin12b[7:12] + opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8) 
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "sw":
                    opcode = format(0b0100011, 'b').zfill(7)
                    func3 = format(0b010, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rS2 = regs[0].strip()
                    rS2_val =  format(reg_dict[rS2], 'b').zfill(5)
                    off_rS =  (regs[1].strip()).replace(')', '')
                    off_rS_spl = off_rS.split('(')
                    rS1 = off_rS_spl[1].strip()
                    rS1_val = format(reg_dict[rS1], 'b').zfill(5)
                    offset_val = int(off_rS_spl[0], 10) 
                    offset_val_binB = (bin(offset_val& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB[-12:]
                    cmd_code = offset_val_bin12b[0:7] + rS2_val + rS1_val + func3 + offset_val_bin12b[7:12] + opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "beq":
                    opcode = format(0b1100011, 'b').zfill(7)
                    func3 = format(0b000, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[0].strip()
                    rB = regs[1].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    addr_offset_label =  regs[2].strip()
                    offset = labels_dict.get(addr_offset_label) - contador_inst
                    offset_val = offset * 4
                    offset_val_binB = (bin(offset_val& 0b1111111111111).replace('0b', '')).zfill(13)
                    offset_val_bin13b = offset_val_binB[-13:]
                    cmd_code = offset_val_bin13b[0] +  offset_val_bin13b[2:8] + rB_val + rA_val + func3 + offset_val_bin13b[8:12] + offset_val_bin13b[1]+ opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex
                
                elif asm[0] == "bne":
                    opcode = format(0b1100011, 'b').zfill(7)
                    func3 = format(0b001, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[0].strip()
                    rB = regs[1].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    addr_offset_label =  regs[2].strip()
                    offset = labels_dict.get(addr_offset_label) - contador_inst
                    offset_val = offset * 4
                    offset_val_binB = (bin(offset_val& 0b1111111111111).replace('0b', '')).zfill(13)
                    offset_val_bin13b = offset_val_binB[-13:]
                    cmd_code = offset_val_bin13b[0] +  offset_val_bin13b[2:8] + rB_val + rA_val + func3 + offset_val_bin13b[8:12] + offset_val_bin13b[1]+ opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "blt":
                    opcode = format(0b1100011, 'b').zfill(7)
                    func3 = format(0b100, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[0].strip()
                    rB = regs[1].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    addr_offset_label =  regs[2].strip()
                    offset = labels_dict.get(addr_offset_label) - contador_inst
                    offset_val = offset * 4
                    offset_val_binB = (bin(offset_val& 0b1111111111111).replace('0b', '')).zfill(13)
                    offset_val_bin13b = offset_val_binB[-13:]
                    cmd_code = offset_val_bin13b[0] +  offset_val_bin13b[2:8] + rB_val + rA_val + func3 + offset_val_bin13b[8:12] + offset_val_bin13b[1]+ opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex
                elif asm[0] == "bge":
                    opcode = format(0b1100011, 'b').zfill(7)
                    func3 = format(0b101, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[0].strip()
                    rB = regs[1].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)                   
                    addr_offset_label =  regs[2].strip()
                    offset = labels_dict.get(addr_offset_label) - contador_inst
                    offset_val = offset * 4               
                    offset_val_binB = (bin(offset_val& 0b1111111111111).replace('0b', '')).zfill(13)
                    offset_val_bin13b = offset_val_binB[-13:]
                    cmd_code = offset_val_bin13b[0] +  offset_val_bin13b[2:8] + rB_val + rA_val + func3 + offset_val_bin13b[8:12] + offset_val_bin13b[1]+ opcode                    
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)                    
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "bltu":
                    opcode = format(0b1100011, 'b').zfill(7)
                    func3 = format(0b110, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[0].strip()
                    rB = regs[1].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)
                    addr_offset_label =  regs[2].strip()
                    offset = labels_dict.get(addr_offset_label) - contador_inst
                    offset_val = offset * 4
                    offset_val_binB = (bin(offset_val& 0b1111111111111).replace('0b', '')).zfill(13)
                    offset_val_bin13b = offset_val_binB[-13:]
                    cmd_code = offset_val_bin13b[0] +  offset_val_bin13b[2:8] + rB_val + rA_val + func3 + offset_val_bin13b[8:12] + offset_val_bin13b[1]+ opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "bgeu":
                    opcode = format(0b1100011, 'b').zfill(7)
                    func3 = format(0b111, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[0].strip()
                    rB = regs[1].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rB_val =  format(reg_dict[rB], 'b').zfill(5)                   
                    addr_offset_label =  regs[2].strip()
                    offset = labels_dict.get(addr_offset_label) - contador_inst
                    offset_val = offset * 4              
                    offset_val_binB = (bin(offset_val& 0b1111111111111).replace('0b', '')).zfill(13)
                    offset_val_bin13b = offset_val_binB[-13:]
                    cmd_code = offset_val_bin13b[0] +  offset_val_bin13b[2:8] + rB_val + rA_val + func3 + offset_val_bin13b[8:12] + offset_val_bin13b[1]+ opcode                  
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)                   
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "jal":
                    opcode = format(0b1101111, 'b').zfill(7)
                    regs = asm[1].split(',')
                    rD = regs[0].strip()
                    rD_val = format(reg_dict[rD], 'b').zfill(5)
                    addr_offset_label =  regs[1].strip()
                    offset = labels_dict.get(addr_offset_label) - contador_inst
                    offset_val = offset * 4
                    offset_val_binB = (bin(offset_val).replace('0b', '')).zfill(20)
                    offset_val_bin20b = offset_val_binB[-20:]
                    cmd_code = offset_val_bin20b[0] + offset_val_bin20b[9:20] + offset_val_bin20b[1:9] + rD_val + opcode
                    cmd_code_hex = hex(int(cmd_code, 2))[2:].zfill(8)  
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "jalr":
                    opcode = format(0b1100111, 'b').zfill(7)
                    func3 = format(0b000, 'b').zfill(3)
                    regs = asm[1].split(',')
                    rA = regs[1].strip()
                    rD = regs[0].strip()
                    rA_val = format(reg_dict[rA], 'b').zfill(5)
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[2].strip() )
                    offset_val_binB = (bin(immdt_decimal& 0b111111111111).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB
                    
                    cmd_code = offset_val_bin12b+rA_val+func3+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex
                
                elif asm[0] == "lui":
                    opcode = format(0b0110111, 'b').zfill(7)
                    regs = asm[1].split(',')
                    rD = regs[0].strip()
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[1].strip() )
                    offset_val_binB = (bin(immdt_decimal).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB
                    
                    cmd_code = offset_val_bin12b+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "auipc":
                    opcode = format(0b0010111, 'b').zfill(7)
                    regs = asm[1].split(',')
                    rD = regs[0].strip()
                    rD_val =  format(reg_dict[rD], 'b').zfill(5)
                    immdt_decimal = int( regs[1].strip() )
                    offset_val_binB = (bin(immdt_decimal).replace('0b', '')).zfill(12)
                    offset_val_bin12b = offset_val_binB
                    
                    cmd_code = offset_val_bin12b+rD_val+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "ecall":
                    opcode = format(0b1110011, 'b').zfill(7)
                    func3 = format(0b000, 'b').zfill(3)
                    imm = format(0b0, 'b').zfill(25)
                    cmd_code = imm+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex

                elif asm[0] == "ebreak":
                    opcode = format(0b1110011, 'b').zfill(7)
                    func3 = format(0b000, 'b').zfill(3)
                    imm = format(0b10000000000000, 'b').zfill(25)
                    cmd_code = imm+opcode
                    cmd_code_hex = (hex(int(cmd_code,2))[2:]).zfill(8)
                    print(f"{hex(contador_inst*4)[2:]} : {cmd_code_hex}", end =" ")
                    a[contador_inst] = cmd_code_hex
            else:
                contador_inst = contador_inst -1    

        label_limpio = linea.split(":")[0]
        if label_limpio in labels_dict:
            print(f"{cont_inst_hexa.zfill(8)} <{label_limpio}>:")
        else:
            print(linea)
                    
count8 = 0
with open(os.path.join(sys.path[0], archivo.split(".")[0]+'_ensamblado'), "w") as f_asm:
    for curr_hex in a:
        f_asm.write(curr_hex + ' ')
        count8 = count8 + 1
        if count8 == 8:
            f_asm.write('\n')
            count8 = 0

print("\n")